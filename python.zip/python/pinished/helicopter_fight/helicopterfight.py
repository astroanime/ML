import pygame
import random

pygame.init()
pygame.font.init()
win = pygame.display.set_mode((1200,700))
pygame.display.set_caption("Helicopter Fight")
run = True
exiting = False
missiles1 = list()
missiles2 = list()
missiles3 = list()
explosions = list()
tanks = list()
copters = list()
#trees = list()
#clouds = list()
#mountains = list()
music = ["track1.mp3","track2.mp3","track3.mp3","track4.mp3","track5.mp3"]
global_timer = 0
exit_timer = -1
stencil = pygame.font.SysFont('Stencil',24)
bigstencil = pygame.font.SysFont('Stencil',64)

expl_snd1 = pygame.mixer.Sound("explode3.mp3")
expl_snd2 = pygame.mixer.Sound("explode4.mp3")
expl_snd3 = pygame.mixer.Sound("explode5.mp3")
rocket_snd = pygame.mixer.Sound("rocketfire1.mp3")
MUSIC_END = pygame.USEREVENT+1
pygame.mixer.music.set_endevent(MUSIC_END)

helicopter = [pygame.image.load("apache1_1.png"), pygame.image.load("apache1_2.png"), pygame.image.load("apache1_3.png")]
chopper = [pygame.image.load("apache2_1.png"), pygame.image.load("apache2_2.png"), pygame.image.load("apache2_3.png")]
apache = [pygame.transform.flip(pygame.image.load("apache3_1.png"),True,False), pygame.transform.flip(pygame.image.load("apache3_2.png"),True,False), pygame.transform.flip(pygame.image.load("apache3_3.png"),True,False)]

tank_spr = [pygame.image.load("tank1.png"), pygame.image.load("tank2.png")]

missile1 = [pygame.image.load("missile1_1.png"), pygame.image.load("missile1_2.png")]
missile2 = [pygame.image.load("missile2_1.png"), pygame.image.load("missile2_2.png")]
missile3 = [pygame.image.load("missile3_1.png"), pygame.image.load("missile3_2.png")]

expl1 = [pygame.image.load("explosion1_1.png"),pygame.image.load("explosion1_2.png"),pygame.image.load("explosion1_3.png"),pygame.image.load("explosion1_4.png"),pygame.image.load("explosion1_5.png"),pygame.image.load("explosion1_6.png"),pygame.image.load("explosion1_7.png")]
expl2 = [pygame.image.load("explosion2_1.png"),pygame.image.load("explosion2_2.png"),pygame.image.load("explosion2_3.png"),pygame.image.load("explosion2_4.png")]

ground = [pygame.image.load("ground1.png"), pygame.image.load("ground2.png"), pygame.image.load("ground3.png")]
trees = [pygame.image.load("tree1.png"), pygame.image.load("tree2.png"), pygame.image.load("tree3.png")]
mountains = [pygame.image.load("mountain1.png"), pygame.image.load("mountain2.png"), pygame.image.load("mountain3.png")]
clouds = [pygame.image.load("cloud1.png"), pygame.image.load("cloud2.png"), pygame.image.load("cloud3.png")]

pygame.display.set_icon(helicopter[0])

def dj():
    music_rand = random.randint(0,4)
    pygame.mixer.music.load(music[music_rand])
    pygame.mixer.music.play()

def baysplosions():
    expl_rand = random.randint(1,3)
    if expl_rand == 1:
        expl_snd1.play()
    elif expl_rand == 2:
        expl_snd2.play()
    elif expl_rand == 3:
        expl_snd3.play()

class playa:
    def __init__(self, anim, x, y, animc):
        self.anim = anim
        self.x = x
        self.y = y
        self.operational = True
        self.animc = animc
        self.velx = 0
        self.vely = 0
        self.mtimer = 0
        self.score = 0
    def draw(self):
        if self.mtimer > 0:
            self.mtimer -= 1
        
        win.blit(self.anim[self.animc//4],(self.x,self.y))
        self.animc += 1
        if self.animc >= 12:
            self.animc = 0

class thing: #generalize for more decoration
    def __init__(self, pic, x, y, width, pics, rand_x = False, rand_y = False):
        self.pic = pic
        self.x = x
        self.y = y
        self.width = width
        self.pics = pics
        self.rand_x = rand_x
        self.rand_y = rand_y
    def draw(self, newpic=False): #do we need newpic?
        win.blit(self.pic,(self.x,self.y))
        self.x -= 5
        if self.x < -self.width:
            if self.rand_x:
                rand_plus = random.randint(1,1200)
                self.x = 1200 + rand_plus
            else:
                self.x = 1200
            if self.rand_y:
                self.y = random.randint(10,550)
            if newpic:
                r = random.random()
                if r > 0.65:
                    self.pic = self.pics[0] #sounds odd, but there are 3 of everything: trees, clouds, etc.
                elif r > 0.33:
                    self.pic = self.pics[1]
                else:
                    self.pic = self.pics[2]

class expl:
    def __init__(self, anim, x, y, width):
        self.anim = anim
        self.x = x
        self.y = y
        self.width = width
        self.animc = 0
    def draw(self):
        win.blit(self.anim[self.animc//3],(self.x,self.y))
        self.animc += 1
        self.x -= 5
        if self.animc >= 3*len(self.anim):
            self.animc = 0
            explosions.remove(self)
            del(self)
            
p = playa(helicopter, 100, 100, 0)
p2= playa(chopper, 120, 150, 5)
         
class missile:
    def __init__(self, anim, x, y, angle, animc, side):
        self.anim = anim
        self.x = x
        self.y = y
        self.angle = angle
        self.animc = animc
        self.side = side #obsolete               !!!!!!!!!!!!!!!!!!!!!!!!!
        self.amogus = True
    def draw(self):
        if self.angle == 0:
            win.blit(pygame.transform.rotate(self.anim[self.animc//3],135),(self.x,self.y))
            self.x -= 20
            self.y -= 10
        elif self.angle == 1:
            win.blit(pygame.transform.rotate(self.anim[self.animc//3],315),(self.x,self.y))
            self.x += 12
            self.y += 10
        elif self.angle == 2:
            win.blit(self.anim[self.animc//3],(self.x,self.y))
            self.x += 25
        elif self.angle == 3:
            win.blit(pygame.transform.rotate(self.anim[self.animc//3],180),(self.x,self.y))
            self.x -= 25
        self.animc +=1
        if self.animc >= 6:
            self.animc = 0
        if self.angle == 0:
            if p.operational:
                if self.x < p.x+40 and self.x+20 > p.x and self.y < p.y+25 and self.y+10 > p.y:
                    p.operational = False
                    e2 = expl(expl2, p.x, p.y, 50)
                    explosions.append(e2)
                    baysplosions()
                    self.amogus = False
            if p2.operational:
                if self.x < p2.x+40 and self.x+20 > p2.x and self.y < p2.y+25 and self.y+10 > p2.y:
                    p2.operational = False
                    e2 = expl(expl2, p2.x, p2.y, 50)
                    explosions.append(e2)
                    baysplosions()
                    self.amogus = False
        if self.angle == 1:
            if self.y >= 680 and self.amogus:
                baysplosions()
                e = expl(expl1, self.x, self.y-40, 50)
                explosions.append(e)
                self.amogus = False
                """if self in missiles1: #lagging              !!!!!!!!!!!!!!!!!!! Use fixed array instead
                    missiles1.remove(self)
                elif self in missiles2:
                    missiles2.remove(self)
                elif self in missiles3:
                    missiles3.remove(self)
                del(self)"""
            if len(tanks) > 0 and self.amogus:
                for t in tanks:
                    if self.y >= 645 and self.x <= t.x+50 and self.x + 20 >= t.x-10:
                        t.x = 2000 + random.randint(100,1200)
                        baysplosions()
                        e = expl(expl1, self.x, self.y-40, 50)
                        explosions.append(e)
                        self.amogus = False
                        if self in missiles1:
                            p.score += 100
                        elif self in missiles2:
                            p2.score += 100
            if len(copters) > 0 and self.amogus: #DOES THAT WORK? I HOPE SO ANYWAY...
                for c in copters:
                    if self.x < c.x+40 and self.x+20 > c.x and self.y < c.y+25 and self.y+10 > c.y:
                        if self in missiles1:
                            p.score += 1000
                        elif self in missiles2:
                            p2.score += 1000
                        e2 = expl(expl2, c.x, c.y, 50)
                        explosions.append(e2)
                        baysplosions()
                        self.amogus = False
                        copters.remove(c)
                        del(c)
        elif self.angle == 2:
            """if self.x < -20 or self.y < -10 or self.x > 1200:
                if self in missiles1: #lagging              !!!!!!!!!!!!!!!!!!! Use fixed array instead
                    missiles1.remove(self)
                elif self in missiles2:
                    missiles2.remove(self)
                elif self in missiles3:
                    missiles3.remove(self)
                del(self)"""
            if len(copters) > 0 and self.amogus:
                for c in copters:
                    if self.x < c.x+40 and self.x+20 > c.x and self.y < c.y+25 and self.y+10 > c.y:
                        if self in missiles1:
                            p.score += 500
                        elif self in missiles2:
                            p2.score += 500
                        e2 = expl(expl2, c.x, c.y, 50)
                        explosions.append(e2)
                        baysplosions()
                        self.amogus = False
                        copters.remove(c)
                        del(c)
        elif self.angle == 3:
            if p.operational:
                if self.x < p.x+40 and self.x+20 > p.x and self.y < p.y+25 and self.y+10 > p.y:
                    p.operational = False
                    e2 = expl(expl2, p.x, p.y, 50)
                    baysplosions()
                    self.amogus = False
                    explosions.append(e2)
            if p2.operational:
                if self.x < p2.x+40 and self.x+20 > p2.x and self.y < p2.y+25 and self.y+10 > p2.y:
                    p2.operational = False
                    e2 = expl(expl2, p2.x, p2.y, 50)
                    baysplosions()
                    self.amogus = False
                    explosions.append(e2)
class tank:
    def __init__(self, x, y):
        self.x = x
        self.y = y
        self.timer = 0
    def draw(self):
        self.timer += random.randint(1,3)
        if self.timer >= 70:
            self.timer = 0
            m = missile(missile3, self.x, self.y, 0, 0, 0)
            missiles3.append(m)
        if self.timer >= 5:
            win.blit(tank_spr[0],(self.x,self.y))
        else:
            win.blit(tank_spr[1],(self.x,self.y))
        self.x -= 5
        if self.x < -40:
            self.x = 2000
            #tanks.remove(self)
            #del(self)

class enemy_copter:
    def __init__(self, anim, x, y, animc):
        self.anim = anim
        self.x = x
        self.y = y
        self.animc = animc
        self.velx = 0
        self.vely = 0
        self.mtimer = 0
    def draw(self):
        rand_velx = 0
        rand_vely = 0
        if self.mtimer > 0:
            self.mtimer -= 1
            if self.mtimer == 15:
                rand_velx = ((random.random()*16)//4) - 2
                rand_vely = ((random.random()*16)//4) - 2
        elif self.mtimer == 0:
            self.mtimer = 30
            m3 = missile(missile3, self.x, self.y, 3, 0, 1)
            missiles3.append(m3)
            rocket_snd.play()
        if self.x >= 1250:
            self.x = 1249
            self.velx = -5
        elif self.x <= 800:
            self.x = 801
            self.velx = 2
        if self.y >= 550:
            self.y = 549
            self.vely = -5
        elif self.y <= 0:
            self.y = 1
            self.vely = 5
        self.velx += rand_velx
        self.vely += rand_vely
        self.x += self.velx
        self.y += self.vely
        win.blit(self.anim[self.animc//4],(self.x,self.y))
        self.animc += 1
        if self.animc >= 12:
            self.animc = 0

dj()
m1 = thing(mountains[0], 400, 590, 100, mountains, True)
m2 = thing(mountains[1], 1200, 590, 100, mountains, True)
m3 = thing(mountains[2], 1800, 590, 100, mountains, True)
t1 = thing(trees[0], 200, 670, 20, trees, True)
t2 = thing(trees[1], 700, 670, 20, trees, True)
t3 = thing(trees[2], 1300, 670, 20, trees, True)
t4 = thing(trees[1], 450, 670, 20, trees, True)
t5 = thing(trees[0], 1700, 670, 20, trees, True)
c1 = thing(clouds[0], 500, 200, 100, clouds, True, True)
c2 = thing(clouds[1], 1100, 500, 100, clouds, True, True)
c3 = thing(clouds[2], 1500, 300, 100, clouds, True, True)
cf1 = thing(clouds[1], 2100, 450, 100, clouds, True, True)
cf2 = thing(clouds[0], 200, 100, 100, clouds, True, True)
groundlist = list()
for i in range(32):
    r = random.random()
    if r > 0.65:
        g = thing(ground[0], 40*i, 690, 40, ground)
    elif r > 0.33:
        g = thing(ground[1], 40*i, 690, 40, ground)
    else:
        g = thing(ground[2], 40*i, 690, 40, ground)
    groundlist.append(g)


def drawwin():
    win.fill((0,150,255))
    c1.draw(True)
    c2.draw(True)
    c3.draw(True)
    m1.draw(True)
    m2.draw(True)
    m3.draw(True)
    t1.draw(True)
    t2.draw(True)
    t3.draw(True)
    t4.draw(True)
    t5.draw(True)
    if p.operational:
        p.draw()
    if p2.operational:
        p2.draw()
    for m in missiles1:
        if m.amogus:
            m.draw()
    for m in missiles2:
        if m.amogus:
            m.draw()
    for m in missiles3:
        if m.amogus:
            m.draw()
    for e in explosions:
        e.draw()
        """for t in tanks: #STAHP!
            if t.x+40 > e.x and t.x < e.x+50:
                tanks.remove(t)
                del(t)"""
    for c in copters:
        c.draw()
    for t in tanks:
        t.draw()
    for g in groundlist:
        g.draw(True)
    cf1.draw(True)
    cf2.draw(True)
    scr = str(p.score)
    scr = "0"*(7-len(scr)) + scr
    text1 = stencil.render("P1: " + scr, True, (0,204,47))
    text1r = text1.get_rect()
    win.blit(text1, text1r)
    scr = str(p2.score)
    scr = "0"*(7-len(scr)) + scr
    text2 = stencil.render("P2: " + scr, True, (160,194,0))
    text2r = text2.get_rect()
    text2r.x += 150
    win.blit(text1, text1r)
    win.blit(text2, text2r)
    pygame.display.update()

def movement():
    keys = pygame.key.get_pressed()
    if keys[pygame.K_w] and p.operational:
        p.vely -= 1
    if keys[pygame.K_a] and p.operational:
        p.velx -= 1
    if keys[pygame.K_s] and p.operational:
        p.vely += 1
    if keys[pygame.K_d] and p.operational:
        p.velx += 1
    if keys[pygame.K_UP] and p2.operational:
        p2.vely -= 1
    if keys[pygame.K_LEFT] and p2.operational:
        p2.velx -= 1
    if keys[pygame.K_DOWN] and p2.operational:
        p2.vely += 1
    if keys[pygame.K_RIGHT] and p2.operational:
        p2.velx += 1
    if keys[pygame.K_f] and p.operational and p.mtimer == 0:
        m = missile(missile1, p.x, p.y, 1, 0, 1)
        missiles1.append(m)
        p.mtimer = 10
        rocket_snd.play()
    if keys[pygame.K_g] and p.operational and p.mtimer == 0:
        m = missile(missile1, p.x, p.y, 2, 0, 1)
        missiles1.append(m)
        p.mtimer = 10
        rocket_snd.play()
    if keys[pygame.K_KP0] and p2.operational and p2.mtimer == 0:
        m2 = missile(missile2, p2.x, p2.y, 1, 0, 1)
        missiles2.append(m2)
        p2.mtimer = 10
        rocket_snd.play()
    if keys[pygame.K_KP1] and p2.operational and p2.mtimer == 0:
        m2 = missile(missile2, p2.x, p2.y, 2, 0, 1)
        missiles2.append(m2)
        p2.mtimer = 10
        rocket_snd.play()
    if p.x >= 500:
        p.x = 499
        p.velx = 0
    if p.x <= 0:
        p.x = 1
        p.velx = 0
    if p2.x >= 500:
        p2.x = 499
        p2.velx = 0
    if p2.x <= 0:
        p2.x = 1
        p2.velx = 0
    if p.y >= 550:
        p.y = 549
        p.vely = 0
    if p.y <= 0:
        p.y = 1
        p.vely = 0
    if p2.y >= 550:
        p2.y = 549
        p2.vely = 0
    if p2.y <= 0:
        p2.y = 1
        p2.vely = 0
    p.x += p.velx
    p.y += p.vely
    p2.x += p2.velx
    p2.y += p2.vely

while run:
    if len(missiles1) > 10:
        missiles1.remove(missiles1[0])
    if len(missiles2) > 10:
        missiles2.remove(missiles2[0])
    if len(missiles3) > 100:
        missiles3.remove(missiles3[0])
    global_timer += 1
    t_limit = (global_timer // 500) + 2
    c_limit = global_timer // 1000
    if t_limit >= 40:
        t_limit = 40
    if c_limit >= 10:
        c_limit = 10
    r = random.random()
    if r > 0.98 and len(tanks) < t_limit:
        t = tank(2000, 660)
        tanks.append(t)
    if r > 0.995 and len(copters) < c_limit:
        r2 = random.random()
        c = enemy_copter(apache, 1250, 50+r2*550, 0)
        copters.append(c)
    clock = pygame.time.Clock()
    clock.tick(35)
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            run = False
            exiting = True
        if event.type == MUSIC_END:
            dj()
    drawwin()
    movement()
    if not p.operational and not p2.operational and exit_timer == -1:
        exit_timer = 90
    if exit_timer > 0:
        exit_timer -= 1
    elif exit_timer == 0:
        run = False
exit_timer = 300
pygame.mixer.music.stop()
if p.score > p2.score:
    pygame.mixer.music.load("p1win.mp3")
elif p.score < p2.score:
    pygame.mixer.music.load("p2win.mp3")
else:
    pygame.mixer.music.load("draw.mp3")
pygame.mixer.music.play()
while not exiting:
    clock = pygame.time.Clock()
    clock.tick(35)
    if exit_timer > 0:
        exit_timer -= 1
    elif exit_timer == 0:
        exiting = True
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            run = False
            exiting = True
    win.fill((0,0,0))
    if p.score > p2.score:
        text = bigstencil.render("PLAYER 1 WINS", True, (0,204,47))
        textr = text.get_rect()
        textr.x = 600-textr.width//2
        textr.y = 350-textr.height//2
        win.blit(text, textr)
    elif p.score < p2.score:
        text = bigstencil.render("PLAYER 2 WINS", True, (160,194,0))
        textr = text.get_rect()
        textr.x = 600-textr.width//2
        textr.y = 350-textr.height//2
        win.blit(text, textr)
    else:
        text = bigstencil.render("DRAW", True, (255,150,0))
        textr = text.get_rect()
        textr.x = 600-textr.width//2
        textr.y = 350-textr.height//2
        win.blit(text, textr)
    pygame.display.update()
pygame.quit()
