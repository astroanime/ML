import pandas as pd
import numpy as np
filename = 'countries.csv'
df_countries = pd.read_csv("countries.csv")
df_countries["hospital_beds_per_thousand"].fillna("0", inplace=True)
dr = df_countries.set_index('location')
highest_LifeExp_countries = dr.nlargest(10, 'life_expectancy')
print(highest_LifeExp_countries)
highest_LifeExp_countries.to_csv('D:/INF323_assign2/highest_LifeExp_countries.csv')