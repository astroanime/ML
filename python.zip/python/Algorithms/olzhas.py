'''x, y, z = map(int, input().strip().split())
volume = x * y * z
print(volume)'''


'''names = ["Олжас", "Абдра", "Рахат", "Шерхан", "Алия"]
#names_starts_a = [name for name in names if name.startswith("А")]
names_starts_a = filter(lambda name: name.startswith("А"), names)
print(tuple(names_starts_a))'''


'''solo = [1, 3, 4, 4443, 568, 103]
logo = solo[:]
logo.append(100)
print(solo)  
print(logo)
elf = logo[::-1]
print(elf)
elf.sort()
print(elf)'''


'''filter_list = (map(int, filter(lambda list: list >=5, list, )))
new_list = [filter_list **2 for filter_list in filter_list]
print(tuple(new_list))'''

'''list = [1, 4, 5, 66,44,45,3,4, 77, 8, 345]
olzhas = { list **2 for list in list if list >=5 }
print(olzhas)'''


'''import random
for i in range(4, 7):
    print(random.randint(1, 10))
'''
'''def f1(func):
    def wrapper(*args, **kwargs):
        print("startted")
        func(*args, **kwargs)
        print("Ended")
    return wrapper
    '''
'''
@f1
def f2():
    print("the middle")

@f1
def f3(x):
    print(x)

f3(56)
f2()'''
'''@f1
def spam():
    print(eggs)
eggs = 42
spam()
print(eggs)'''

'''travel_cities = {'Kazakhstan': {1: 'Almaty',
                                2: 'Astana',
                                3: 'Karaganda'},
                 'USA': {1: 'Boston',
                         2: 'Los Angeles',
                         3: 'San Francisco',
                         4: 'Seattle'},
                 'Europe': {1: 'Rome',
                            2: 'Paris',
                            3: 'London'}}
a = travel_cities['Kazakhstan']
print(a)
'''
s = "OR(NOT(AND(A,B)),A)"
if s[0]=="O":
        sub = s[3:len(s)-1]
        b = 0
        d = 0
        for i in range(len(sub)): 
            if sub[i] == "(":
                b+=1
            elif sub[i]==")":
                b-=1
            elif sub[i]=="," and b == 0:
                d = i
        print(sub[0:d-1])
        print(sub[d+1:len(sub)])