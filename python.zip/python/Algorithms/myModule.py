def myFunc(x):
    return x+5
class Point(object):
    def __init__(self, x, y):
        self.x = x
        self.y = y
        print ("nice you created a dog")
    def speak(self):
        print(self.x)
    def __add__(self,p):
        return Point(self.x + p.x, self.y+p.y)
    def __str__(self):
        return "(" + str(self.x) + ',' + str(self.y) + ")"
class Cat(Point):
    def __init__(self, name,age, color):
        super().__init__(name, age)
        self.color = color
olzhas = Point(5,7)
mate = Point(3,8)
rock = olzhas + mate
print(rock)