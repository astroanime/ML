s = [3,42,423,21,2,4,5,654,777,8]
def bubble(s):
    for i in range(len(s)):
        ordered = False
        for j in range(i+1,len(s)):
            if s[i] > s[j]:
                s[i],s[j] = s[j],s[i]
                ordered = True
        if ordered == False:
            break
    print(s)
def selection(s):
    for i in range(len(s)):
        min_index = i
        for j in range(i+1,len(s)):
            if s[min_index]>s[j]:
                min_index = j
        s[min_index],s[i] = s[i],s[min_index]
    print(s)
def insertion(s):
    for i in range(len(s)):
        key = s[i]
        j = i-1
        while j >=0 and key < s[j] :
                s[j+1] = s[j]
                j -= 1
        s[j+1] = key
        print(s)
    print(s)
def pivot(s):
    for i in range(len(s)):
        less = []
        more = []
        pivot = s[len(s)-1]
        for j in range(len(s)-1):
            if s[j] > pivot:
                more.append(s[j])
            else:
                less.append(s[j])
    less.append(pivot)
    total = less + more
    print(total)
print(pivot(s))