s = "absa"
word = ''
m = 0
for i in range(len(s)):
    if word.find(s[i]) !=1:
        if m < len(word):
            m = len(word)
        word = word.replace(s[0],"")
        print(word)
    else:
        word += s[i]
        m +=1
        print(word)
print(m)