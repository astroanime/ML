'''
x = 10

list = ['apple', 'pear', 'strawberry']
list.append('hat')
list[1:1] = 'hello'
for ass in list:
    print(ass) 

text  = input('please input something')
print(text.strip())
print(len(text.strip()))
print(text.lower())
print(text.upper())
print(text.split('.'))

text = 'hello Olzhas how are you'
print(text[0:4:1])

file = open('Algorithms\py.txt', 'r')
f = file.readlines()
newList = []
for line in f:
    newList.append(line.strip())
print(newList)

file = open('Algorithms\py.txt', 'w')
file.write('python')
file.close()

string = input('please enter something')
if string.count('_') > 0:
    print('not good')
else:
    print('its ok')
    
import math
import myModule
a = math.sqrt(10)
print(myModule.myFunc(7))

name = 'TIM'
print(f'Hello {name}')

tup = (1,2,3,4,5)
lst = [1,2,3,4,5]
string = 'hello'
dic={'a':1,"b":2}
coords = [4,5]

a,b,c,d,e = tup
f,g = dic.values()
x,y = coords

x=[0 for i in range(100) if i%2 == 0 ]
print(x)

x = 'hello'*5
print(x)

args = [1,2,3]
kwargs = {'arg2':1, 'arg1':2,'arg3': 5}
def fun1 (arg1,arg2,arg3):
    print(arg1,arg2,arg3)

fun1(**kwargs)

target = 7
search= [1,2,3,4,5,6,7]
for element in search:
    if element == target:
        print('i found it')
        break
else:
    print("i didnt found it")
''''''
s="{}{{{{(((("
bool = False
for i in range(len(s)):
    s = s.replace("()", "").replace("[]","").replace("{}", "")
if len(s) == 0:
    bool = True
else:
    bool = False
print(bool)



3
from random import randint
arr = [1000]
import time


for i in range(999):
    value = randint(1,200)
    arr.append(value)
st = time.time()
if arr.index(100) == 0:
    print(-1)
else:
    print(arr.index(100))
et = time.time()
time = et - st
print(time, " seconds")
'''
'''
4
import random
import string
import time
#letters = string.ascii_lowercase
#a = ''.join(random.choice(letters) for i in range(10000))
a = "bab"
st = time.time()
if a == a[::-1]:
    print("true")
else:
    print("false")
et = time.time()
time = et - st
print(time, " seconds")



from collections import deque
numbersDeque = deque((20,40,60,80))
ol = numbersDeque.popleft()
print(ol)

stones = [2,2]
stones.sort()
while len(stones)>1:
            max1 = stones[-1]
            max2 = stones[-2]
            if max1 == max2:
                stones.remove(max1)
                stones.remove(max2)
            else:
                stones.remove(max2)
                stones[-1] = max1 - max2
                stones.sort()
for x in range(len(stones)):
    print(stones[x])

def recur_fibo(n):
    if n <= 2:
        return n
    else:
        return(recur_fibo(n-1) + recur_fibo(n-2))
a, b = input("").split(" ")
x = len(a)
y = len(b)
num1 = 0
for i in range(len(a)):
    num1 = num1 + recur_fibo(x-i)*int(a[i])
num2 = 0
for i in range(len(b)):
    num2 = num2 + recur_fibo(y-i)*int(b[i])
num3 = num1+num2
z = x + y
fnum = 0
for i in range(z):
    if recur_fibo(z-i)<num3:
        fnum = z-i
        break
temp = recur_fibo(fnum)
stop = "1"
for i in range(fnum-1):
    if num3 >= temp + recur_fibo(fnum-1-i):
        stop = stop + "1"
        temp = temp + recur_fibo(fnum-1-i)
    else:
        stop = stop + "0"
print(str(stop))

import math

fin  = open("input.txt")
fout = open("output.txt","w")
C,D = map(int, fin.readline().split())
A,B = map(int, fin.readline().split())

if A > B :
    A,B = B,A
if C > D:
    C,D = D,C
AC = int((A**2 + B**2)**(1/2))
FC = int((AC**2 - C**2)**(1/2))
CAB = math.degrees(math.atan(B/A))
FAC = math.degrees(math.atan(FC/C))
BAF = CAB + FAC
BAE = 90 - BAF
DAF = BAE
GDA = BAE
GE = D*(math.sin(GDA)) + A*(math.cos(BAE))
if GE <= D:
    fout.write("Possible")
else:
    fout.write("Impossible")

fin.close()
fout.close()

#
list = []
x = 23979879879879879879878977897897798799879878778986798

def fact(x):
    if x == 1:
        list.append(1)
        return list
    else:
        i = int(x**(1/3))
        list.append(i)
    return fact(x-i**3)
list2 = fact(x)
if len(list2) > 8:
    print("IMPOSSIBLE")
    print(list2)
else:
    word = ""
    for i in list2:
        word += " " + str(i)
    print(word)

def solve(text):
    if len(s) == 1:
        return A and B
    elif s[0] == 'N':
        return not solve(s[4:len(s)])
    elif s[0] == "A":
        sub = s[4:len(s)]
        res = True
        begin = 0
        count = 0
        b = 0
        for i in range(len(sub)):
            count += 1
            if sub[i] == "(":
                b += 1
            if sub[i] == ")":
                b -= 1
            if sub[i] == "," and b == 0:
                res = res & solve(sub[begin:count-1])
                begin += count
                count = 0
        return res
    elif s[0] == "O":
        sub = s[3:len(s)]
        res = False
        begin = 0
        count = 0
        b = 0
        for i in range(len(sub)):
            count += 1
            if sub[i] == "(":
                b += 1
            if sub[i] == ")":
                b -= 1
            if sub[i] == "," and b == 0:
                res = res | solve(sub[begin:count-1])
                begin += count
                count = 0
        return res
fin = open("D:\python\Algorithms\input.txt")
s = fin.readline()
n, m = map(int, fin.readline().split())
for i in range(n):
    for j in range(m):
        a = fin.readline()
        if a[0] == "A" and a[2] == "T":
            A = True
        elif a[0] == "A" and a[2] == "F":
            A = False
        elif a[0] == "B" and a[2] == "T":
            B = True
        else:
            B = False

fin.close()
'''
s = "abc"
a = s.index("a")
